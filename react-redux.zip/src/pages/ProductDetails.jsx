// ProductDetails.js
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux'; // Adjust the path accordingly
import { fetchProductDetails } from '../redux/features/product/productSlice';
import { addToCart, decrementQuantity, incrementQuantity } from '../redux/features/cart/cartSlice';
import InnerImageZoom from 'react-inner-image-zoom';
import MainLayout from '../layout/MainLayout';
import { fetchRelatedProducts } from '../redux/features/product/relatedProductSlice';

const ProductDetails = () => {
    const { productId } = useParams();
    const dispatch = useDispatch();
    const selectedProduct = useSelector((state) => state.product.selectedProduct);
    const relatedProducts = useSelector((state) => state.relatedProduct.relatedProducts); // Get related products from the Redux store
    const isLoading = useSelector((state) => state.product.detailsLoading);
    const isError = useSelector((state) => state.product.detailsError);

    const [currentImage, setCurrentImage] = useState(0);

    // Fetch product details using the productId
    useEffect(() => {
        dispatch(fetchProductDetails(productId)); // Pass productId as an argument
        dispatch(fetchRelatedProducts())
    }, [dispatch, productId]);

    // Check if the product details are still loading
    if (isLoading) {
        return <div>Loading...</div>;
    }

    // Check if there was an error fetching product details
    if (isError) {
        return <div>Error fetching product details.</div>;
    }

    // Check if the product details are available
    if (!selectedProduct) {
        return <div>No product details available.</div>;
    }

    const switchImage = (index) => {
        setCurrentImage(index);
    };

    const handleAddToCart = () => {
        dispatch(addToCart(selectedProduct));
    };

    // const handleIncrementQuantity = () => {
    //     dispatch(incrementQuantity({ itemId: selectedProduct.id, quantity: 1 }));
    // };

    // const handleDecrementQuantity = () => {
    //     dispatch(decrementQuantity({ itemId: selectedProduct.id, quantity: 1 }));
    // };

    console.log(relatedProducts)

    return (

        <>

            <MainLayout>



                <div style={{ display: "flex", maxWidth: '1200px', margin: 'auto', marginTop: '100px', gap: '20px' }}>

                    <div>
                        {/* <img style={{ width: '100%', hight: '400px' }} src={selectedProduct.images[currentImage]}
                        alt="" /> */}

                        <InnerImageZoom src={selectedProduct.images[currentImage]} zoomSrc={selectedProduct.images[currentImage]} />
                        <div style={{ display: 'flex', gap: '10px' }}>
                            {selectedProduct.images.map((image, index) => (
                                <img
                                    key={index}
                                    style={{ width: '100px', cursor: 'pointer' }}
                                    src={image}
                                    alt=""
                                    onClick={() => switchImage(index)}
                                />
                            ))}
                        </div>
                    </div>

                    <div>
                        <h2>Product Details</h2>
                        <p>Product ID: {selectedProduct.id}</p>
                        <p>Title: {selectedProduct.title}</p>
                        <p>Description: {selectedProduct.description}</p>
                        <p>Price per unit: ${selectedProduct.price}</p>
                        {/* <p>Total Price: ${selectedProduct.price * selectedProduct.quantity}</p>        */}
                        {/* <p>Price: ${selectedProduct.price} * {selectedProduct.quantity} = {selectedProduct.totalPrice}</p> */}
                        <button onClick={handleAddToCart}>Add to Cart</button>
                        {/* <span>{selectedProduct.quantity}</span>
                <button onClick={handleIncrementQuantity}>Increment Quantity</button>
            <button onClick={handleDecrementQuantity}>Decrement Quantity</button> */}
                    </div>
                    {/* Display other product details */}
                </div>


                {/* Display related products */}
                <div>
                    <h2>Related Products</h2>
                    {relatedProducts.map((product) => (
                        <div key={product.id}>
                            <p>{product.title}</p>
                            {/* Display other related product details */}
                        </div>
                    ))}
                </div>

            </MainLayout>
        </>

    );
};

export default ProductDetails;
