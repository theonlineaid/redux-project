import React from 'react'
import Nav from '../compoments/Nav'
import Breadcrumbs from '../compoments/Breadcrumbs'
import { useLocation } from 'react-router-dom';

export default function MainLayout({ children }) {

    const location = useLocation();
    const isHomeRoute = location.pathname === '/';

    
    return (
        <>
            <Nav />
            {!isHomeRoute && <Breadcrumbs />}
            <main style={{ maxWidth: '1200px', margin: 'auto' }}>{children}</main>
        </>
    )
}


