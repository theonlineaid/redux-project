# print('Hello World!')

# print(type('Hello, World!'))

# # String
# print(type('Hello, World!'))
# # Integer
# print(type(15))
# print(type(-24))
# print(type(0))
# print(type(1))
# # Float
# print(type(3.14))
# print(type(0.5))
# print(type(1.0))
# print(type(-5.0))
# # Boolean
# print(type(True))
# print(type(False))

# x = 56+65+89+45+78.5+98.2
# print(x)
# print(type(x))

x = 125//24
print(x)
print(type(x))